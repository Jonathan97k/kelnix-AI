import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Lazy Gemini client helper
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set. Using intelligent algorithmic fallbacks for reel generation.");
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Script & Story Generator
app.post("/api/generate-script", async (req, res) => {
  try {
    const {
      theme = "Travel & Lifestyle",
      tone = "Cinematic & Inspiring",
      photoCount = 5,
      photoDescriptions = [],
      customPrompt = "",
      targetAudience = "Instagram & TikTok",
    } = req.body;

    const ai = getAI();

    if (!ai) {
      // Fallback creative generator if no API key
      const fallbackThemes: Record<string, any> = {
        "Travel & Lifestyle": {
          title: "Wanderlust Chronicles",
          hook: "Moments you never want to forget ✨",
          musicMood: "Uplifting Lo-Fi & Ambient Beats",
          recommendedBpm: 120,
          captions: [
            "Chasing new horizons 🌅",
            "Lost in the right direction",
            "These views hit different",
            "Collecting memories, not things",
            "Until the next adventure ✈️",
            "Golden hours and good vibes",
            "Hidden gems along the way",
            "Pure serenity"
          ],
          narrations: [
            "Sometimes you just have to step outside and let the world surprise you.",
            "Finding magic in every little turn and quiet moment.",
            "Every frame tells a story of where we've been and where we're going.",
            "Take the leap, soak it all in, and don't look back.",
            "Memories made here will last forever."
          ],
          hashtags: "#travelreels #wanderlust #cinematic #goldenhour #lifestyle #travelphotography #explore #aesthetic",
          captionText: "Every journey has a story worth telling. Here's a glimpse into the moments that made time stand still. 🌍✨ Which place should I explore next?"
        },
        "Aesthetic Vlog": {
          title: "Aesthetic Day in Life",
          hook: "Romanticizing the simple moments ☕🤍",
          musicMood: "Soft Warm Acoustic & Lo-Fi",
          recommendedBpm: 96,
          captions: [
            "Morning light & slow sips ☕",
            "Finding beauty in ordinary things",
            "A gentle pause in a fast world",
            "Little details you might miss",
            "Grateful for today's peace 🕊️",
            "Warm coffee, warm thoughts"
          ],
          narrations: [
            "Here is your reminder to slow down and romanticize the small things.",
            "Morning sunbeams, quiet spaces, and warm energy.",
            "Creating peace in the middle of everyday life.",
            "Today was simply good for the soul."
          ],
          hashtags: "#aesthetic #vlog #softlife #slowliving #dailyroutine #aestheticreels #mindfulness",
          captionText: "A soft chapter. Finding peace in the quiet routines and gentle sunlight. 🕊️☕ Tell me: what was the highlight of your day?"
        },
        "High Energy / Fitness": {
          title: "Unstoppable Grind",
          hook: "Proof that consistency beats talent every single time 🔥",
          musicMood: "Hard Trap & Bass Wave",
          recommendedBpm: 138,
          captions: [
            "Show up before the world wakes up ⚡",
            "No excuses, just execution",
            "Building the best version daily",
            "The hard work happens in silence",
            "Level up season is here 🏆"
          ],
          narrations: [
            "Nobody sees the early mornings or the reps in the dark, but the results will speak for themselves.",
            "Push past the comfort zone. That's where growth begins.",
            "Stay hungry, stay locked in, and never negotiate with weakness."
          ],
          hashtags: "#fitnessmotivation #gymreels #discipline #grindset #fitnessjourney #levelup #workout",
          captionText: "Consistency is the only cheat code. Keep putting in the work even when nobody is watching. ⚡🔥"
        }
      };

      const selected = fallbackThemes[theme] || fallbackThemes["Travel & Lifestyle"];
      const generatedCaptions = selected.captions.slice(0, photoCount);
      while (generatedCaptions.length < photoCount) {
        generatedCaptions.push(`Frame ${generatedCaptions.length + 1} • Pure vibe ✨`);
      }

      const generatedNarrations = selected.narrations.slice(0, photoCount);
      while (generatedNarrations.length < photoCount) {
        generatedNarrations.push("Another unforgettable perspective caught on camera.");
      }

      return res.json({
        success: true,
        data: {
          title: selected.title,
          hook: selected.hook,
          musicMood: selected.musicMood,
          recommendedBpm: selected.recommendedBpm,
          captions: generatedCaptions,
          narrations: generatedNarrations,
          socialCaption: selected.captionText,
          hashtags: selected.hashtags,
          recommendedTransition: "whip-left",
          recommendedPacing: 2.2,
        },
      });
    }

    // Call Gemini 3.7 Flash for rich, tailored reel script & metadata
    const prompt = `You are a viral social media video director & editor for Instagram Reels, TikTok, and YouTube Shorts.
Generate a cohesive, viral, cinematic reel concept tailored for ${photoCount} sequential photos.

Context:
- Theme / Vibe: ${theme}
- Tone: ${tone}
- Number of photo slides: ${photoCount}
- Photo details/hints: ${photoDescriptions.length ? photoDescriptions.join(" | ") : "User uploaded photos for this theme"}
- Custom instructions: ${customPrompt || "Make it captivating, modern, and viral"}
- Target: ${targetAudience}

Return strict JSON with the following structure:
{
  "title": "Short catchy reel title (3-5 words)",
  "hook": "Compelling visual hook for the first 3 seconds",
  "musicMood": "Description of perfect background track (e.g. 'Chill Lo-Fi guitar beat', 'Fast-paced Cyberpunk synth', 'Warm cinematic piano buildup')",
  "recommendedBpm": 120 (a number between 85 and 150),
  "recommendedPacing": 2.2 (seconds per slide, number between 1.4 and 3.5),
  "recommendedTransition": "one of: crossfade, whip-left, whip-right, zoom-in, glitch, flash, slide-up",
  "captions": ["Short punchy on-screen caption for slide 1 (max 7 words with 1 emoji)", "Caption for slide 2...", ... exactly ${photoCount} items],
  "narrations": ["Voiceover script line for slide 1 (1-2 smooth sentences)", "Voiceover line for slide 2...", ... exactly ${photoCount} items],
  "socialCaption": "Engaging full Instagram/TikTok caption copy with call-to-action",
  "hashtags": "8-12 relevant viral hashtags formatted as #tag1 #tag2..."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.8,
      },
    });

    const text = response.text || "{}";
    const parsed = JSON.parse(text);

    // Validate lengths
    if (!Array.isArray(parsed.captions) || parsed.captions.length < photoCount) {
      parsed.captions = Array.from({ length: photoCount }, (_, i) => `Moment ${i + 1} ✨`);
    }
    if (!Array.isArray(parsed.narrations) || parsed.narrations.length < photoCount) {
      parsed.narrations = Array.from({ length: photoCount }, () => "Capturing the true feeling of the moment.");
    }

    res.json({
      success: true,
      data: parsed,
    });
  } catch (error: any) {
    console.error("Error in /api/generate-script:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to generate reel script",
    });
  }
});

// Image Analysis with Vision
app.post("/api/analyze-photos", async (req, res) => {
  try {
    const { images } = req.body; // array of { base64: string, mimeType?: string }
    const ai = getAI();

    if (!ai || !images || !images.length) {
      return res.json({
        success: true,
        data: {
          detectedTheme: "Visual Memories",
          detectedVibe: "Aesthetic & Modern",
          suggestedCaptions: (images || []).map((_: any, i: number) => `Captured moment ${i + 1} ✨`),
        },
      });
    }

    // Prepare parts with up to 5 images for analysis
    const limitedImages = images.slice(0, 5);
    const parts: any[] = limitedImages.map((img: { base64: string; mimeType?: string }) => ({
      inlineData: {
        mimeType: img.mimeType || "image/jpeg",
        data: img.base64.replace(/^data:image\/[a-z]+;base64,/, ""),
      },
    }));

    parts.push({
      text: `Analyze these sequential photos and determine:
1. The overall story or theme that connects them.
2. A unique, engaging, short on-screen caption (3-7 words) for each photo in sequence.
3. The best aesthetic filter style (e.g., 'cinematic', 'golden-hour', 'vintage-film', 'nordic-cool', 'cyberpunk').
4. Suggested music vibe and BPM.

Return JSON:
{
  "detectedTheme": "e.g. Sunset Coastal Roadtrip",
  "detectedVibe": "e.g. Golden hour warm nostalgia",
  "suggestedFilter": "golden-hour",
  "suggestedCaptions": ["caption for image 1", "caption for image 2", ...],
  "musicMood": "e.g. Chill indie acoustic beat",
  "recommendedBpm": 115
}`,
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    const text = response.text || "{}";
    const parsed = JSON.parse(text);

    res.json({
      success: true,
      data: parsed,
    });
  } catch (error: any) {
    console.error("Error in /api/analyze-photos:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze photos",
    });
  }
});

// Gemini Text-To-Speech (TTS) endpoint
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voiceName = "Kore" } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required" });
    }

    const ai = getAI();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: "Gemini API key not configured for TTS. Client can use browser Web Speech API fallback.",
      });
    }

    // Supported voices: Kore, Puck, Charon, Fenrir, Zephyr
    const validVoices = ["Kore", "Puck", "Charon", "Fenrir", "Zephyr"];
    const chosenVoice = validVoices.includes(voiceName) ? voiceName : "Kore";

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Say naturally and cinematically: ${text}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: chosenVoice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    const mimeType = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.mimeType || "audio/pcm;rate=24000";

    if (!base64Audio) {
      throw new Error("No audio returned from Gemini TTS");
    }

    res.json({
      success: true,
      data: {
        base64Audio,
        mimeType,
      },
    });
  } catch (error: any) {
    console.error("Error in /api/tts:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to synthesize voice",
    });
  }
});

// Start Server with Vite Middleware
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ReelCraft server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
